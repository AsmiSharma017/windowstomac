const express = require('express');
const app = express();

app.get("/home",(req, res)=>{
    let followers = ["ajay", "vijay", "Aryan","abcd"]
    res.render("home.ejs", {followers});
    
})
app.get("/about",(req,res)=>{
    res.render("about.ejs");
})
app.get("/contact",(req,res)=>{
    res.render("contact.ejs");
})
//dynamic routes
app.get("/ig/:username", (req, res)=>{
    const {username} = req.params
    let data = {
        posts: [
            "/images/post1.jpg",
            "/images/post2.jpg",
            "/images/post3.jpg"
        ]
    }
    console.log(req.params);    
    res.render("insta.ejs", {username, data});
    console.log(data);    
})
app.listen(3030,()=>{
    console.log(`http://localhost:3030/home`);
    
})