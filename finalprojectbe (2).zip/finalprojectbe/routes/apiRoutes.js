const express = require('express');
const path = require('path');
const fs = require('fs');

const router = express.Router();

// ✅ Serve index.html on root URL
router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

// ✅ Serve other HTML pages
router.get('/login', (req, res) => res.sendFile(path.join(__dirname, '../public/login.html')));
router.get('/user', (req, res) => res.sendFile(path.join(__dirname, '../public/user.html')));
router.get('/bmi', (req, res) => res.sendFile(path.join(__dirname, '../public/bmi.html')));
router.get('/checkout', (req, res) => res.sendFile(path.join(__dirname, '../public/checkout.html')));
router.get('/contact', (req, res) => res.sendFile(path.join(__dirname, '../public/contact.html')));

// ✅ Handle login authentication
router.post('/login', (req, res) => {
    const { username, password } = req.body;

    fs.readFile(path.join(__dirname, '../models/users.json'), 'utf-8', (err, data) => {
        if (err) return res.status(500).send("Server Error");

        const users = JSON.parse(data);
        const user = users.find(u => u.username === username && u.password === password);

        if (user) {
            return res.status(302).redirect('/user');
        } else {
            return res.status(302).redirect('/');
        }
    });
});

module.exports = router;
